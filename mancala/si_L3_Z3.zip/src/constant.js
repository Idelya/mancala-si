const PLAYER_1 = {
    color: '#243321'
}

const PLAYER_2 = {
    color: '#342343'
}

